桐間へきる Web制作テンプレート
-----------------------------------
このテンプレートは、個人・配信者・お店など向けに制作された
ポートフォリオ用見本です。

【利用条件】
・個人・商用どちらも利用可能（著作権表記を残してください）
・再配布や販売は禁止です
・編集・改変は自由です

【作者】
桐間へきる（hekiru-portfolio）

【連絡先】
GitHub: https://github.com/happyojyou-jpg/hekiru-portfolio

Includes a placeholder section for Google Maps embed.